import { useEffect, useState } from "react";

export default function useTasks() {
  const [tasks, setTasks] = useState(
    () => JSON.parse(localStorage.getItem("taskflow_final")) || []
  );

  useEffect(() => {
    localStorage.setItem("taskflow_final", JSON.stringify(tasks));
  }, [tasks]);

  const createTask = (task) => {
    setTasks((prev) => [
      ...prev,
      { ...task, id: Date.now(), status: "To Do", comments: [] },
    ]);
  };

  const updateTask = (id, updated) => {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, ...updated } : t)));
  };

  const deleteTask = (id) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  const moveTask = (id, status) => {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, status } : t)));
  };

  const addComment = (taskId, text) => {
    if (!text.trim()) return;

    setTasks((prev) =>
      prev.map((t) => {
        if (t.id !== taskId) return t;

        const newComment = {
          id: Date.now(),
          text: text.trim(),
          time: new Date().toISOString(),
        };

        return {
          ...t,
          comments: [...(t.comments || []), newComment],
        };
      })
    );
  };

  return {
    tasks,
    setTasks,
    createTask,
    updateTask,
    deleteTask,
    moveTask,
    addComment,
  };
}
