export const isOverdue = (task) => {
  if (!task.deadline) return false;
  if (task.status === "Done") return false;
  return new Date(task.deadline) < new Date();
};

export const formatDate = (dateStr) => {
  if (!dateStr) return "No deadline";
  const d = new Date(dateStr);
  return d.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};
