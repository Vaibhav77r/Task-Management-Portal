export const canCreate = (role) => role !== "Viewer";
export const canEdit = (role) => role === "Admin" || role === "Manager";
export const canDelete = (role) => role === "Admin";
