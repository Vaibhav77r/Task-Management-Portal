import React from "react";
import { Kanban, BarChart3, LogOut } from "lucide-react";

export default function Sidebar({ view, setView, role, onLogout }) {
  return (
    <aside className="w-64 bg-slate-900 text-white flex flex-col shadow-2xl z-10">
      <div className="p-8 pb-12 text-2xl font-black tracking-tighter text-blue-500 italic">
        TASKFLOW
      </div>

      <nav className="p-4 space-y-2 flex-1 font-semibold text-sm">
        <div
          onClick={() => setView("board")}
          className={`flex items-center gap-3 p-4 rounded-2xl cursor-pointer transition-all ${
            view === "board"
              ? "bg-blue-600 shadow-lg shadow-blue-600/20 text-white"
              : "text-slate-500 hover:bg-slate-800"
          }`}
        >
          <Kanban size={18} /> Board View
        </div>

        <div
          onClick={() => setView("analytics")}
          className={`flex items-center gap-3 p-4 rounded-2xl cursor-pointer transition-all ${
            view === "analytics"
              ? "bg-blue-600 shadow-lg shadow-blue-600/20 text-white"
              : "text-slate-500 hover:bg-slate-800"
          }`}
        >
          <BarChart3 size={18} /> Analytics
        </div>
      </nav>

      <div className="p-6 border-t border-slate-800 space-y-3">
        <div className="bg-slate-800 p-4 rounded-2xl text-[10px] text-slate-400 font-bold uppercase tracking-widest text-center">
          Logged in as: {role}
        </div>

        <button
          onClick={onLogout}
          className="w-full bg-red-500/20 text-red-300 hover:bg-red-500/30 px-4 py-3 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition-all"
        >
          <LogOut size={16} />
          Logout
        </button>
      </div>
    </aside>
  );
}
