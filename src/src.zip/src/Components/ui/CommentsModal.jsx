import React, { useState, useEffect } from "react";
import ModalShell from "./ModalShell";

export default function CommentsModal({
  isOpen,
  onClose,
  task,
  onAddComment,
}) {
  const [commentText, setCommentText] = useState("");

  useEffect(() => {
    setCommentText("");
  }, [task, isOpen]);

  if (!isOpen || !task) return null;

  return (
    <ModalShell title="Comments" subtitle={task.title} onClose={onClose}>
      <div className="space-y-6">
        {/* Comments list */}
        <div className="max-h-[280px] overflow-y-auto space-y-3 pr-2">
          {(task.comments || []).length === 0 ? (
            <div className="text-slate-400 text-sm font-medium">
              No comments yet. Add the first one 👇
            </div>
          ) : (
            (task.comments || []).map((c) => (
              <div
                key={c.id}
                className="bg-slate-50 border border-slate-200 rounded-2xl p-4"
              >
                <p className="text-sm text-slate-700 font-semibold">
                  {c.text}
                </p>
                <p className="text-[10px] text-slate-400 font-bold mt-2">
                  {new Date(c.time).toLocaleString("en-IN")}
                </p>
              </div>
            ))
          )}
        </div>

        {/* Add comment */}
        <div className="space-y-3">
          <textarea
            rows="3"
            className="w-full border-2 border-slate-100 p-5 rounded-[1.5rem] focus:border-blue-500 outline-none transition-all font-medium resize-none shadow-sm text-sm"
            placeholder="Write a comment..."
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
          />

          <button
            onClick={() => {
              onAddComment(task.id, commentText);
              setCommentText("");
            }}
            className="w-full py-4 bg-blue-600 text-white rounded-[1.5rem] font-black uppercase tracking-widest text-xs hover:bg-blue-700 transition-all active:scale-95"
          >
            Add Comment
          </button>
        </div>
      </div>
    </ModalShell>
  );
}
