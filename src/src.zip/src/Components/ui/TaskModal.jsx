import React from "react";
import ModalShell from "./ModalShell";

export default function TaskModal({
  isOpen,
  onClose,
  onSave,
  editingTask,
  formData,
  setFormData,
}) {
  if (!isOpen) return null;

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      onSave();
    }
  };

  return (
    <ModalShell
      title={editingTask ? "Edit Details" : "Create Task"}
      onClose={onClose}
    >
      <div className="space-y-8">
        {/* Title */}
        <div>
          <label className="block text-[10px] font-black uppercase text-slate-400 tracking-widest mb-3 px-1">
            Task Headline
          </label>
          <input
            autoFocus
            className="w-full border-2 border-slate-100 p-5 rounded-[1.5rem] focus:border-blue-500 outline-none transition-all font-bold text-lg shadow-sm"
            placeholder="e.g. Design API structure"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            onKeyDown={handleKeyDown}
          />
        </div>

        {/* Description */}
        <div>
          <label className="block text-[10px] font-black uppercase text-slate-400 tracking-widest mb-3 px-1">
            Detailed Description
          </label>
          <textarea
            rows="4"
            className="w-full border-2 border-slate-100 p-5 rounded-[1.5rem] focus:border-blue-500 outline-none transition-all font-medium resize-none shadow-sm text-sm"
            placeholder="Add specific details or instructions..."
            value={formData.description}
            onChange={(e) =>
              setFormData({ ...formData, description: e.target.value })
            }
          />
        </div>

        {/* Deadline */}
        <div>
          <label className="block text-[10px] font-black uppercase text-slate-400 tracking-widest mb-3 px-1">
            Deadline
          </label>
          <input
            type="date"
            className="w-full border-2 border-slate-100 p-5 rounded-[1.5rem] focus:border-blue-500 outline-none transition-all font-bold shadow-sm"
            value={formData.deadline}
            onChange={(e) =>
              setFormData({ ...formData, deadline: e.target.value })
            }
          />
        </div>

        {/* Priority */}
        <div>
          <label className="block text-[10px] font-black uppercase text-slate-400 tracking-widest mb-3 px-1">
            Set Priority
          </label>
          <select
            className="w-full border-2 border-slate-100 p-5 rounded-[1.5rem] focus:border-blue-500 outline-none bg-white font-black uppercase text-xs tracking-widest shadow-sm cursor-pointer"
            value={formData.priority}
            onChange={(e) =>
              setFormData({ ...formData, priority: e.target.value })
            }
          >
            <option value="Low">Low Priority</option>
            <option value="Medium">Medium Priority</option>
            <option value="High">High Priority</option>
          </select>
        </div>

        {/* Buttons */}
        <div className="flex gap-4 pt-6">
          <button
            onClick={onClose}
            className="flex-1 py-5 text-slate-400 font-black uppercase tracking-widest text-xs hover:bg-slate-50 rounded-[1.5rem] transition-all"
          >
            Discard
          </button>

          <button
            onClick={onSave}
            className="flex-1 py-5 bg-slate-900 text-white rounded-[1.5rem] font-black uppercase tracking-widest text-xs hover:bg-blue-600 shadow-2xl shadow-blue-500/40 transition-all active:scale-95"
          >
            {editingTask ? "Update Record" : "Add to Board"}
          </button>
        </div>
      </div>
    </ModalShell>
  );
}
