import React from "react";
import { X } from "lucide-react";

export default function ModalShell({ title, subtitle, onClose, children }) {
  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xl flex items-center justify-center z-50 p-6">
      <div className="bg-white rounded-[3rem] shadow-2xl w-full max-w-xl overflow-hidden animate-in fade-in zoom-in duration-300 border border-white/20">
        {/* Header */}
        <div className="px-10 py-8 border-b border-slate-100 flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-black text-slate-900 tracking-tighter uppercase">
              {title}
            </h2>
            {subtitle && (
              <p className="text-slate-500 text-sm mt-1 font-medium">
                {subtitle}
              </p>
            )}
          </div>

          <button
            onClick={onClose}
            className="hover:bg-red-50 hover:text-red-500 p-3 rounded-full transition-all"
          >
            <X size={24} />
          </button>
        </div>

        {/* Body */}
        <div className="p-10">{children}</div>
      </div>
    </div>
  );
}
