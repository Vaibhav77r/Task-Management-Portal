import React from "react";
import {
  PieChart as RePieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
} from "recharts";

const CHART_COLORS = ["#6366f1", "#f59e0b", "#10b981"];

export default function AnalyticsDashboard({ tasks }) {
  const chartData = [
    { name: "To Do", value: tasks.filter((t) => t.status === "To Do").length },
    {
      name: "In Progress",
      value: tasks.filter((t) => t.status === "In Progress").length,
    },
    { name: "Done", value: tasks.filter((t) => t.status === "Done").length },
  ];

  return (
    <div className="h-full p-12 overflow-y-auto">
      <div className="flex justify-between items-end mb-10">
        <div>
          <p className="text-blue-600 font-bold text-xs uppercase tracking-widest mb-2">
            Workspace Statistics
          </p>
          <h2 className="text-4xl font-black tracking-tight">
            Analytics Dashboard
          </h2>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        <div className="bg-white p-10 rounded-[2.5rem] shadow-sm border border-slate-200 h-[450px]">
          <h3 className="font-black text-slate-800 mb-8 uppercase text-xs tracking-widest">
            Status Distribution
          </h3>
          <ResponsiveContainer width="100%" height="90%">
            <RePieChart>
              <Pie
                data={chartData}
                innerRadius={90}
                outerRadius={125}
                paddingAngle={8}
                dataKey="value"
              >
                {chartData.map((e, i) => (
                  <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend iconType="circle" />
            </RePieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white p-10 rounded-[2.5rem] shadow-sm border border-slate-200 h-[450px]">
          <h3 className="font-black text-slate-800 mb-8 uppercase text-xs tracking-widest">
            Active Task Counts
          </h3>
          <ResponsiveContainer width="100%" height="90%">
            <BarChart data={chartData}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="value" radius={[12, 12, 0, 0]} barSize={40}>
                {chartData.map((e, i) => (
                  <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
