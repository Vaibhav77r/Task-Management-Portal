import React from "react";
import Column from "./Column";

export default function Board({
  tasks,
  role,
  onEdit,
  onDelete,
  onComments,
}) {
  const columns = ["To Do", "In Progress", "Done"];

  return (
    <div className="h-full p-10 flex gap-8 overflow-x-auto bg-slate-50">
      {columns.map((col) => (
        <Column
          key={col}
          id={col}
          title={col}
          tasks={tasks.filter((t) => t.status === col)}
          role={role}
          onEdit={onEdit}
          onDelete={onDelete}
          onComments={onComments}
        />
      ))}
    </div>
  );
}
