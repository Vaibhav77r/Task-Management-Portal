import React from "react";
import { Trash2, Edit3, MessageCircle, CalendarDays } from "lucide-react";
import { useDraggable } from "@dnd-kit/core";
import { CSS } from "@dnd-kit/utilities";

import { canDelete, canEdit } from "../../utils/roles";
import { isOverdue, formatDate } from "../../utils/date";

const getPriorityStyle = (priority) => {
  switch (priority) {
    case "High":
      return "bg-red-50 text-red-600 border-red-100";
    case "Medium":
      return "bg-amber-50 text-amber-600 border-amber-100";
    case "Low":
      return "bg-emerald-50 text-emerald-600 border-emerald-100";
    default:
      return "bg-slate-50 text-slate-500 border-slate-100";
  }
};

export default function TaskCard({ task, role, onEdit, onDelete, onComments }) {
  const { attributes, listeners, setNodeRef, transform, isDragging } =
    useDraggable({ id: task.id });

  const style = {
    transform: CSS.Translate.toString(transform),
    zIndex: isDragging ? 50 : "auto",
    opacity: isDragging ? 0.5 : 1,
  };

  const overdue = isOverdue(task);

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...listeners}
      {...attributes}
      className={`bg-white p-4 rounded-2xl shadow-sm border mb-3 group cursor-grab active:cursor-grabbing hover:border-blue-400 transition-all
        ${overdue ? "border-red-400" : "border-slate-200"}
      `}
    >
      <div className="flex justify-between items-start mb-2">
        <p className="text-sm font-bold text-slate-700 leading-tight">
          {task.title}
        </p>

        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          {canEdit(role) && (
            <button
              onPointerDown={(e) => e.stopPropagation()}
              onClick={() => onEdit(task)}
              className="text-blue-400 hover:text-blue-600 p-1"
            >
              <Edit3 size={14} />
            </button>
          )}

          {canDelete(role) && (
            <button
              onPointerDown={(e) => e.stopPropagation()}
              onClick={() => onDelete(task.id)}
              className="text-red-300 hover:text-red-500 p-1"
            >
              <Trash2 size={14} />
            </button>
          )}
        </div>
      </div>

      {task.description && (
        <p className="text-[11px] text-slate-500 mb-3 line-clamp-2 leading-relaxed">
          {task.description}
        </p>
      )}

      <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 mb-2">
        <div className={`flex items-center gap-1 ${overdue ? "text-red-500" : ""}`}>
          <CalendarDays size={12} />
          {formatDate(task.deadline)}
          {overdue && (
            <span className="ml-2 bg-red-50 text-red-500 px-2 py-0.5 rounded-full border border-red-100">
              Overdue
            </span>
          )}
        </div>

        <button
          onPointerDown={(e) => e.stopPropagation()}
          onClick={() => onComments(task)}
          className="flex items-center gap-1 text-slate-400 hover:text-blue-600 transition-all"
        >
          <MessageCircle size={14} />
          {task.comments?.length || 0}
        </button>
      </div>

      <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-50">
        <span className="text-[9px] bg-slate-100 text-slate-400 px-2 py-0.5 rounded font-mono uppercase">
          #{task.id.toString().slice(-4)}
        </span>

        <span
          className={`text-[10px] px-2 py-0.5 rounded-full border font-bold ${getPriorityStyle(
            task.priority
          )}`}
        >
          {task.priority}
        </span>
      </div>
    </div>
  );
}
