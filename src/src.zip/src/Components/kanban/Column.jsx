import React from "react";
import { useDroppable } from "@dnd-kit/core";
import TaskCard from "./TaskCard";
import { Plus } from "lucide-react";

export default function Column({
  id,
  title,
  tasks,
  role,
  onEdit,
  onDelete,
  onComments,
}) {
  const { setNodeRef } = useDroppable({ id });

  return (
    <div className="w-80 flex-shrink-0 flex flex-col h-full">
      <div className="flex justify-between items-center mb-4 px-2">
        <h3 className="font-bold text-slate-400 uppercase text-[10px] tracking-[0.2em]">
          {title}
        </h3>
        <span className="bg-white border border-slate-200 text-slate-600 text-[10px] px-2 py-0.5 rounded-full font-bold shadow-sm">
          {tasks.length}
        </span>
      </div>

      <div
        ref={setNodeRef}
        className="bg-slate-200/40 border-2 border-dashed border-slate-300 rounded-[2rem] p-3 flex-1 overflow-y-auto min-h-[450px]"
      >
        {tasks.map((task) => (
          <TaskCard
            key={task.id}
            task={task}
            role={role}
            onEdit={onEdit}
            onDelete={onDelete}
            onComments={onComments}
          />
        ))}

        {tasks.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center opacity-20 py-20 grayscale">
            <Plus size={40} strokeWidth={1} />
            <p className="text-[10px] font-bold uppercase tracking-widest mt-2">
              No tasks added yet
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
