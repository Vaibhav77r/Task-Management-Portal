import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    email: "",
    password: "",
    role: "Viewer",
  });

  const handleLogin = (e) => {
    e.preventDefault();

    // Demo Auth (Frontend only)
    if (!formData.email.trim() || !formData.password.trim()) return;

    localStorage.setItem("token", "demo-token-123");
    localStorage.setItem("role", formData.role);
    localStorage.setItem("user", JSON.stringify({ email: formData.email }));

    navigate("/app");
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-[2rem] shadow-xl p-10">
        <h1 className="text-3xl font-black tracking-tight text-slate-900">
          Login
        </h1>
        <p className="text-slate-500 mt-2 text-sm">
          Login to access your Task Management Portal
        </p>

        <form onSubmit={handleLogin} className="mt-10 space-y-6">
          <div>
            <label className="block text-[10px] font-black uppercase text-slate-400 tracking-widest mb-2">
              Email
            </label>
            <input
              className="w-full border-2 border-slate-100 p-4 rounded-[1.2rem] outline-none focus:border-blue-500"
              placeholder="Enter your email"
              value={formData.email}
              onChange={(e) =>
                setFormData({ ...formData, email: e.target.value })
              }
            />
          </div>

          <div>
            <label className="block text-[10px] font-black uppercase text-slate-400 tracking-widest mb-2">
              Password
            </label>
            <input
              type="password"
              className="w-full border-2 border-slate-100 p-4 rounded-[1.2rem] outline-none focus:border-blue-500"
              placeholder="Enter password"
              value={formData.password}
              onChange={(e) =>
                setFormData({ ...formData, password: e.target.value })
              }
            />
          </div>

          <div>
            <label className="block text-[10px] font-black uppercase text-slate-400 tracking-widest mb-2">
              Role (Demo)
            </label>
            <select
              className="w-full border-2 border-slate-100 p-4 rounded-[1.2rem] outline-none focus:border-blue-500 bg-white font-bold"
              value={formData.role}
              onChange={(e) =>
                setFormData({ ...formData, role: e.target.value })
              }
            >
              <option value="Admin">Admin</option>
              <option value="Manager">Manager</option>
              <option value="Viewer">Viewer</option>
            </select>
          </div>

          <button
            type="submit"
            className="w-full py-4 bg-blue-600 text-white rounded-[1.5rem] font-black uppercase tracking-widest text-xs hover:bg-blue-700 transition-all active:scale-95"
          >
            Login
          </button>
        </form>

        <p className="text-sm text-slate-500 mt-8 text-center">
          Don’t have an account?{" "}
          <Link className="text-blue-600 font-bold" to="/signup">
            Sign up
          </Link>
        </p>
      </div>
    </div>
  );
}
