import React, { useState } from "react";
import { Search, Plus } from "lucide-react";
import {
  DndContext,
  closestCorners,
  PointerSensor,
  useSensor,
  useSensors,
} from "@dnd-kit/core";
import { useNavigate } from "react-router-dom";

import Sidebar from "../Components/shared/Sidebar";
import Board from "../Components/kanban/Board";
import AnalyticsDashboard from "../Components/analytics/AnalyticsDashboard";

import TaskModal from "../Components/ui/TaskModal";
import CommentsModal from "../Components/ui/CommentsModal";

import useTasks from "../hooks/useTasks";
import { canCreate } from "../utils/roles";

export default function TaskBoardPage() {
  const navigate = useNavigate();
  const role = localStorage.getItem("role") || "Viewer";

  const [view, setView] = useState("board");
  const [searchQuery, setSearchQuery] = useState("");

  // tasks from hook
  const { tasks, createTask, updateTask, deleteTask, moveTask, addComment } =
    useTasks();

  // ---------------- MODAL STATES ----------------
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState(null);

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    priority: "Medium",
    deadline: "",
  });

  const [isCommentsOpen, setIsCommentsOpen] = useState(false);
  const [activeTaskId, setActiveTaskId] = useState(null);

  // ---------------- DND ----------------
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } })
  );

  const handleDragEnd = (event) => {
    const { active, over } = event;

    if (over && ["To Do", "In Progress", "Done"].includes(over.id)) {
      moveTask(active.id, over.id);
    }
  };

  // ---------------- LOGOUT ----------------
  const logout = () => {
    localStorage.clear();
    navigate("/login");
  };

  // ---------------- SEARCH ----------------
  const filteredTasks = tasks.filter(
    (t) =>
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // ---------------- TASK MODAL FUNCTIONS ----------------
  const openCreateModal = () => {
    setEditingTask(null);
    setFormData({
      title: "",
      description: "",
      priority: "Medium",
      deadline: "",
    });
    setIsTaskModalOpen(true);
  };

  const openEditModal = (task) => {
    setEditingTask(task);
    setFormData({
      title: task.title,
      description: task.description || "",
      priority: task.priority,
      deadline: task.deadline || "",
    });
    setIsTaskModalOpen(true);
  };

  const handleSaveTask = () => {
    if (!formData.title.trim()) return;

    if (editingTask) {
      updateTask(editingTask.id, formData);
    } else {
      createTask(formData);
    }

    setIsTaskModalOpen(false);
  };

  // ---------------- COMMENTS FUNCTIONS ----------------
  const openComments = (task) => {
    setActiveTaskId(task.id);
    setIsCommentsOpen(true);
  };

  const activeTask = activeTaskId
    ? tasks.find((t) => t.id === activeTaskId)
    : null;

  // ---------------- UI ----------------
  return (
    <div className="flex h-screen bg-slate-50 text-slate-900 font-sans">
      <Sidebar view={view} setView={setView} role={role} onLogout={logout} />

      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-24 bg-white/80 backdrop-blur-md border-b border-slate-200 px-10 flex items-center justify-between shrink-0 z-10">
          <div className="relative w-[400px]">
            <Search
              className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300"
              size={18}
            />
            <input
              type="text"
              placeholder="Search anything..."
              className="w-full bg-slate-100/50 border border-slate-200 pl-12 pr-4 py-3 rounded-2xl outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all font-medium"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {/* Create only Admin/Manager */}
          {canCreate(role) && (
            <button
              onClick={openCreateModal}
              className="bg-blue-600 text-white px-8 py-3.5 rounded-2xl font-black text-sm uppercase tracking-widest flex items-center gap-2 hover:bg-blue-700 shadow-xl shadow-blue-500/30 active:scale-95 transition-all"
            >
              <Plus size={18} strokeWidth={4} /> New Task
            </button>
          )}
        </header>

        {/* Views */}
        <div className="flex-1 overflow-hidden">
          {view === "board" ? (
            <DndContext
              sensors={sensors}
              collisionDetection={closestCorners}
              onDragEnd={handleDragEnd}
            >
              <Board
                tasks={filteredTasks}
                role={role}
                onEdit={openEditModal}
                onDelete={deleteTask}
                onComments={openComments}
              />
            </DndContext>
          ) : (
            <AnalyticsDashboard tasks={tasks} />
          )}
        </div>
      </main>

      {/* TASK MODAL */}
      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => setIsTaskModalOpen(false)}
        onSave={handleSaveTask}
        editingTask={editingTask}
        formData={formData}
        setFormData={setFormData}
      />

      {/* COMMENTS MODAL */}
      <CommentsModal
        isOpen={isCommentsOpen}
        onClose={() => setIsCommentsOpen(false)}
        task={activeTask}
        onAddComment={addComment}
      />
    </div>
  );
}
