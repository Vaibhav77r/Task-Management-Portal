import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Signup() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
  });

  const handleSignup = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.password) return;

    // Demo signup
    navigate("/login");
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-[2rem] shadow-xl p-10">
        <h1 className="text-3xl font-black tracking-tight text-slate-900">
          Sign Up
        </h1>
        <p className="text-slate-500 mt-2 text-sm">
          Create your account to start managing tasks
        </p>

        <form onSubmit={handleSignup} className="mt-10 space-y-6">
          <div>
            <label className="block text-[10px] font-black uppercase text-slate-400 tracking-widest mb-2">
              Full Name
            </label>
            <input
              className="w-full border-2 border-slate-100 p-4 rounded-[1.2rem] outline-none focus:border-blue-500"
              placeholder="Enter your name"
              value={formData.name}
              onChange={(e) =>
                setFormData({ ...formData, name: e.target.value })
              }
            />
          </div>

          <div>
            <label className="block text-[10px] font-black uppercase text-slate-400 tracking-widest mb-2">
              Email
            </label>
            <input
              className="w-full border-2 border-slate-100 p-4 rounded-[1.2rem] outline-none focus:border-blue-500"
              placeholder="Enter your email"
              value={formData.email}
              onChange={(e) =>
                setFormData({ ...formData, email: e.target.value })
              }
            />
          </div>

          <div>
            <label className="block text-[10px] font-black uppercase text-slate-400 tracking-widest mb-2">
              Password
            </label>
            <input
              type="password"
              className="w-full border-2 border-slate-100 p-4 rounded-[1.2rem] outline-none focus:border-blue-500"
              placeholder="Create password"
              value={formData.password}
              onChange={(e) =>
                setFormData({ ...formData, password: e.target.value })
              }
            />
          </div>

          <button
            type="submit"
            className="w-full py-4 bg-slate-900 text-white rounded-[1.5rem] font-black uppercase tracking-widest text-xs hover:bg-blue-600 transition-all active:scale-95"
          >
            Create Account
          </button>
        </form>

        <p className="text-sm text-slate-500 mt-8 text-center">
          Already have an account?{" "}
          <Link className="text-blue-600 font-bold" to="/login">
            Login
          </Link>
        </p>
      </div>
    </div>
  );
}
